//INTRODUCTION-------------------------------------------------------------------------------------------------------------------------------------------------
/*
The drive.cpp file declares the drive function, which is called in the user control function in main.cpp. The drive function contains what the robot does 
during driver control. This is where you will write the code for your driver control, such as how the robot moves and what the buttons do. You can also have 
other functions in this file if you want, but the drive function is the main one. You can also have different drive functions for different control schemes, 
but make sure to call the correct one in main.cpp.
*/

//STRUCTURE EXPLANATION----------------------------------------------------------------------------------------------------------------------------------------
/*
The drive function is a void function, meaning it does not return anything. The drive function contains an infinite loop, which allows the robot to be 
controlled indefinitely during driver control. Inside the loop, you can read the controller's joystick and button values to control the robot's movement and 
actions. You can also use timers to create delays or to measure how long certain actions take. Since the drive function uses motor and sensor values, you will
need to include the robotConfig.h header file at the top of this file. You can also include other header files if you have written them.
*/

//CODE---------------------------------------------------------------------------------------------------------------------------------------------------------
#include "robotConfig.h" //Includes the robotConfig header file so you can use motor functions.
#include "vex.h" //Isn't strictly necessary since robotConfig.h already includes vex.h. Simply here in case the #include "vex.h" ever gets changed in 
                 //robotConfig.h

void drive() { //Declares the drive function.
    timer Timer; //Creates a timer to measure time after last joystick input.

    int deadband = 5; //The joystick value allowed before joystick controls starts taking effect.
    bool moved = false; //Boolean that records if there was joystick movement within the last 0.3 seconds.
    
    //NON-CHASSIS MOTOR AND PISTON CONTROL VARIABLES
    bool FrontMotorForward = false; //Example control variable
    bool FrontMotorReverse = false; //Example control variable
    bool BackMotorForward = false; //Example control variable
    bool BackMotorReverse = false; //Example control variable

    bool pistonsState = false; //Example control variable
    bool pistons2State = false; //Example control variable

    while (true) { //Infinite loop to ensure continuous and smooth driving
        double elapsed = Timer.time(seconds); //Assigns the current value of the timer to a variable

        double a3 = Controller1.Axis3.position() * 1; //Records the position of axis 3 of the controller. Multiply by a number to tune sensitivity.
        double a1 = Controller1.Axis1.position() * 1; //Records the position of axis 1 of the controller. Multiply by a number to tune sensitivity.

        double left  = a3 + a1; //Calculates the volt output of the left chassis.
        double right = a3 - a1; //Calculates the volt output of the right chassis.

        double move = abs(Controller1.Axis3.position()); //Assigns the absolute value of axis 3 to move variable.
        
        if (move > deadband) { //Checks if the movement of axis 3 is greater than deadband. This code's purpose is to set the stop type to brake 
                               //after 0.3 seconds of no movement. This prevents the floaty feeling for the driver. If a driver prefers the floaty
                               //feel, then comment this if-statement out.
            moved = true; //The robot has moved if the if-statement evaluates to true.
            Timer.clear(); //Clears the timer.
        }
        
        if (elapsed > 0.3) { //Checks if the time elapsed since the last movement has exceeded 0.3 seconds.
            moved = false; //Changed the moved variable back to false if true.
        }

        if (abs(left) < deadband) { //Checks if there is input beyond the deadband.
            if (moved == false) { //Checks if there was input within the last 0.3 seconds.
                LeftMotor_group.stop(brake); //Uses brake to stop the robot if no movement input from the last 0.3 seconds.
            } else { //There was input within the last 0.3 seconds.
                LeftMotor_group.stop(coast); //Allows the robot to coast and "float" for a small period of time before braking.
            }
        } else { //There is input.
            LeftMotor_group.spin(forward, left * 0.12, volt); //Spins the motors based on the calculated output.
        }

        if (abs(right) < deadband) { //Checks if there is input beyond the deadband.
            if (moved == false) { //Checks if there was input within the last 0.3 seconds.
                RightMotor_group.stop(brake); //Uses brake to stop the robot if no movement input from the last 0.3 seconds.
            } else { //There was input within the last 0.3 seconds.
                RightMotor_group.stop(coast); //Allows the robot to coast and "float" for a small period of time before braking.
            }
        } else { //There is input.
            RightMotor_group.spin(forward, right * 0.12, volt); //Spins the motors based on the calculated output.
        }

        if (Controller1.ButtonR1.pressing()) { //Checks if a button is pressed.
            FrontMotorForward = true; //Sets variable to true
            BackMotorForward = true; //Sets variable to true
        }

        if (Controller1.ButtonR2.pressing()) { //Checks if a button is pressed.
            FrontMotorReverse = true; //Sets variable to true
            BackMotorReverse = true; //Sets variable to true
        }

        if (Controller1.ButtonX.pressing()) { //Checks if a button is pressed.
            if (pistonsState == true) {pistonsState = false;} //Sets variable to false
            else if (pistonsState == false) {pistonsState = true;} //Sets variable to true
            while (Controller1.ButtonX.pressing()) {wait(5, msec);} //Avoids detection again before the finger has been raised.
        }

        if (Controller1.ButtonA.pressing()) { //Checks if a button is pressed.
            if (pistons2State == true) {pistons2State = false;} //Sets variable to false
            else if (pistons2State == false) {pistons2State = true;} //Sets variable to true
            while (Controller1.ButtonA.pressing()) {wait(5, msec);} //Avoids detection again before the finger has been raised.
        }

        // Reset the control variables
        if (!Controller1.ButtonR1.pressing() && !Controller1.ButtonR2.pressing() && 
            !Controller1.ButtonX.pressing() && !Controller1.ButtonA.pressing()) {
            FrontMotorForward = false;
            FrontMotorReverse = false;
            BackMotorForward = false;
            BackMotorReverse = false;
        }

        //Spins motor based on the state of the control variable
        if (FrontMotorForward == true) {
            FrontMotor.spin(reverse, 12, volt);
        } else if (FrontMotorReverse == true) {
            FrontMotor.spin(forward, 12, volt);
        } else {
            FrontMotor.stop(coast);
        }

        if (BackMotorForward == true) {
            BackMotor.spin(reverse, 12, volt);
        } else if (BackMotorReverse == true) {
            BackMotor.spin(forward, 12, volt);
        } else {
            BackMotor.stop(coast);
        }

        //Activates piston based on the state of the control variable
        if (pistonsState == true) {
            Pistons.set(true);
        } else if (pistonsState == false) {
            Pistons.set(false);
        }

        //Activates piston based on the state of the control variable
        if (pistons2State == true) {
            Pistons2.set(true);
        } else if (pistons2State == false) {
            Pistons2.set(false);
        }

        wait(20, msec); //Do not remove this. If removed, the robot will disconnect easily during matches. I am telling you this based on personal experience.
    }
}

//TROUBLESHOOTING----------------------------------------------------------------------------------------------------------------------------------------------
/*
Q: My robot keeps disconnecting during use
A: Didn't I tell you to not remove the wait(20, msec);

Q: I wrote something to activate on button press but it doesn't work
A: Did you download the program into the brain? If yes, then make sure the control variable name and the device name are correct. Also check if you reset
   the control variables in the reset section.

Q: My problem is not in the troubleshooting section
A: Go to the GitHub repository, click on the "Issues" tab, and submit a new issue describing your problem. I will respond.
*/