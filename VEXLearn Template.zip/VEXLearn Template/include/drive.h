//INTRODUCTION-------------------------------------------------------------------------------------------------------------------------------------------------
/*
This is the header file for drive.cpp. For more explanation on what header files are, check the PDF.
*/

//STRUCTURE EXPLANATION----------------------------------------------------------------------------------------------------------------------------------------
/*
The format for writing a function in a header file is:

return_type function_name(arguments);

It is VERY IMPORTANT that your return_type function_name(arguments) are identical to those in drive.cpp. A quick way to write this is to copy the
function declaration line from drive.cpp then removing the {} brackets and everything inside, then adding a semicolon (;) to the end of it.
*/

//CODE---------------------------------------------------------------------------------------------------------------------------------------------------------
#pragma once //This prevents the duplication of the header file when included multiple times. For more information, reference the PDF file. Should be supported
             //by any modern compiler.

void drive(); //The drive function that contains what the robot does in user control phase.

//TROUBLESHOOTING----------------------------------------------------------------------------------------------------------------------------------------------
/*
Q: I can't find my drive function in other files
A: Make sure you have added your drive function to the header file. Make sure the header file is included in the other files, if it isn't, add 
   "#include "drive.h" into the other files. Make sure your spelling for the function name is correct and identical in drive.cpp, drive.h, and the file.

Q: My problem is not in the troubleshooting section
A: Go to the GitHub repository, click on the "Issues" tab, and submit a new issue describing your problem. I will respond.
*/