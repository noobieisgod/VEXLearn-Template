//INTRODUCTION-------------------------------------------------------------------------------------------------------------------------------------------------
/*
This is the header file for display.cpp. For more explanation on what header files are, check the PDF.
*/

//STRUCTURE EXPLANATION----------------------------------------------------------------------------------------------------------------------------------------
/*
The format for writing a function in a header file is:

return_type function_name(arguments);

It is VERY IMPORTANT that your return_type function_name(arguments) are identical to those in display.cpp. A quick way to write this is to copy the
function declaration line from display.cpp then removing the {} brackets and everything inside, then adding a semicolon (;) to the end of it.
*/

//CODE---------------------------------------------------------------------------------------------------------------------------------------------------------
#pragma once //This prevents the duplication of the header file when included multiple times. For more information, reference the PDF file. Should be supported
             //by any modern compiler.

void BrainRender(); //Called in main.cpp, so it is initialized in header file.
void ControllerRender(); //Called in main.cpp, so it is initialized in header file.

//TROUBLESHOOTING----------------------------------------------------------------------------------------------------------------------------------------------
/*
Q: I can't find my display function in other files
A: Make sure you have added your display function to the header file. Make sure the header file is included in the other files, if it isn't, add 
   "#include "display.h" into the other files. Make sure your spelling for the function name is correct and identical in display.cpp, display.h, and the file.

Q: My problem is not in the troubleshooting section
A: Go to the GitHub repository, click on the "Issues" tab, and submit a new issue describing your problem. I will respond.
*/