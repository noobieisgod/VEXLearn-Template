//INTRODUCTION-------------------------------------------------------------------------------------------------------------------------------------------------
/*
MORE SPECIFIC EXPLANATIONS AND TIPS ARE IN THE PDF FILE!
An autonomous function is used during competitions 15 second autonomous or skills autonomous. Autonomous code makes your robot follow a set path you 
wrote in the function. If you have ever used scratch, you will know that there are change x by and change y by functions. When you call the movement
functions inside the autonomous functions, it does the same thing.

If you are planning on writing skills code, you should use the JAR Template or the LemLib template. These templates have functions for odometry written 
and ready for you to use. Odometry is very important in skills because you will be covering much longer distances than in the 15 second autonomous. 
My advice, switch to JAR Template or LemLib for skills as my template is mostly focused in teaching and simpler tasks.
*/

//STRUCTURE EXPLANATION----------------------------------------------------------------------------------------------------------------------------------------
/*
Your auto.cpp will start by including any header file that contains the movement functions. If you haven't changed how my file structures work, then you
will include these header files. Include follows this format:

#include whatever_file

In this file's case it would be:

#include "vex.h"
#include "robotConfig.h"
#include "movement.h"

Function declarations follow the normal function declaring format.

return_type function_name(arguments) {
    contents
}

Generally, autonomous functions declaring would look like this.

void blueRight() {
    contents
}

Return type is void because autonomous functions generally don't return anything. You can pass arguments if you need it for something in your autonomous,
but generally you don't need any. You should also name your autonomous function by what it is doing, for example, the blueRight name indicates that the
function is the blueRight autonomous.
*/

//CODE---------------------------------------------------------------------------------------------------------------------------------------------------------
#include "vex.h" //This allows the wait function and other VEX functions.
#include "robotConfig.h" //This allows motors and pistons to be controlled.
#include "movement.h" //This allows you to call functions from the movement.cpp file. (Make sure you did add the function name to the header file.)

using namespace vex; //All functions are using the namespace vex (basically version of function). No need to change this.

//Here is how the 15 second autonomous functions would look like.
void BlueRight() {
   //movement code
}

void BlueLeft() {
   //movement code
}

void RedRight() {
   //movement code
}

void RedLeft() {
   //movement code
}
//Generally, VEX V5 field is symmetrical, meaning you could put the same movement code for BlueRight and RedRight and the same movement code for BlueLeft 
//and RedLeft.
//Skills function also follow the same declaration format.
void Skills() {
    //movement code
}
//Of course, you are free to name your autonomous functions anything, these are just examples. You can also have different autonomous functions for the 
//same side to cover a different route.

//Here is an example autonomous code, this is just a function calling demonstration, it doesn't achieve any specific goal when run. This function is not 
//in the header file, it's here for demonstration only.
void example() {
   move(100, 0, 8, 6); //Move 100 centimeters with 8 being max voltage and the exit voltage being 6.
   turn(15, 8); //Turn to 15 degrees relative to origin with 8 being max voltage.
   move(100, 0, 8); //Move 100 centimeters with 8 being max voltage.
   FrontMotor.spin(forward, 12, volt); //Spins the front motor at 12 volts.
   wait(1, sec); //Waits
   FrontMotor.stop(coast); //Stops the front motor using coast.
   Pistons.set(true); //Fires the pistons
   move(-100, 0, 8); //Move 100 centimeters backward with 8 being max voltage.
   turn(180, 8); //Turn to 180 degrees heading relative to origin with 8 being max voltage.
   move(10, 0, 8); //Move 10 centimeters with 8 being max voltage.
   BackMotor.spin(forward, 12, volt); //Spins the back motor at 12 volts.
}

//TROUBLESHOOTING----------------------------------------------------------------------------------------------------------------------------------------------
/*
Q: I changed my autonomous code but the robot did not change
A: If your change was very small, it is likely that you couldn't see it visually. Check by making the robot move a massive distance (six meters etc.), if
   you still don't see the robot moving that six meters, then make sure you are running the correct autonomous function in main.cpp.

Q: I can't find my autonomous function in main
A: Make sure you have added your autonomous function to the header file. Make sure the header file is included in the main.cpp, if it isn't add 
   "#include "auto.h" into main.cpp. Make sure your spelling for the function name is correct and identical in auto.cpp, auto.h, and main.cpp.

Q: My autonomous code was working perfectly last time I tuned it but now it is a mess
A: Check if you accidentally changed anything. If you did not, then this is quite normal. Run to run differences are common and as long as it doesn't deviate
   too much, you can correct it by tuning the turning angle and distance. Tuning is very common, every team does this, you will do this in between matches
   during competitions too.

Q: How do I run different routes in between matches without having to load the file onto the VEX Brain every time
A: Load the code onto a different slot on the Brain. For example, slot 1 is BlueRight (changed in main.cpp), slot 2 is BlueLeft etc.

Q: My robot's starting alignment is not 0 degrees but the robot's alignment is initialized based on the starting alignment
A: Add Inertial.setHeading(your starting heading/alignment) at the start of your autonomous function.

Q: My problem is not in the troubleshooting section
A: Go to the GitHub repository, click on the "Issues" tab, and submit a new issue describing your problem. I will respond.
*/