//INTRODUCTION-------------------------------------------------------------------------------------------------------------------------------------------------
/*
I would say this is the most complex part of VEX software. If your movement codes are not good, you will struggle with writing autonomous functions. And in
seasons such as VEX PushBack and VEX High Stakes where autonomous performance is very important, you will likely lose if your autonomous performance isn't
good.

If anything seems too complex, don't be afraid to access resources like AI (chatGPT, Gemini, Grok, Claude, etc.), Reddit (https://www.reddit.com/r/vex/), 
VEX Forum (https://www.vexforum.com/), your mentor, the VEXLearn Github Issues page, the PDF document, or Discord communities (Robolytics is a very big one: 
https://discord.gg/robolytics-1272763279739191296).

While both RPM and volt versions of functions are available, volt control is generally superior and recommended because it directly dictates motor output, 
while RPM can be affected more by temperature and battery remaining. My advice, only use the volt functions, there are no good reasons to use RPM control
unless it becomes meta in a future VEX season.
*/

//STRUCTURE EXPLANATION----------------------------------------------------------------------------------------------------------------------------------------
/*
Your movement.cpp will start by including any header file that contains the movement functions. If you haven't changed how my file structures work, then you
will include the vex.h header file as well as robotConfig.h header file. Include follows this format:

#include whatever_file

In this file's case it would be:

#include "vex.h"
#include "robotConfig.h"

Function declarations follow the normal function declaring format.

return_type function_name(arguments) {
    contents
}

Generally, movement functions declaring would look like this.

void move(double dis, double heading, double volt_max, double exit_volt = 0, bool stop = true) {
    contents
}

Return type is void because the movement functions should not return anything. You pass the functions arguments like distance to travel, the heading to
follow, the max volt allowed, and etc. You should also name your autonomous function by what it is doing, for example, the move function moves the robot.
*/

//CODE---------------------------------------------------------------------------------------------------------------------------------------------------------
#include "vex.h" //A variable called wheel_2r is declared in this header file. wheel_2r is the diameter of the wheel. you can declare the variable inside
                 //the functions if you want, I declared it in vex.h because I won't have to change many different wheel_2r if the wheel size changes.
#include "robotConfig.h" //This header file contains all the motors, pistons, inertial sensors, and other sensors on your robot. Since the functions require
                         //data from the sensors and the motors to work, we have to include this file.

void motor_spin(double L_volt, double R_volt) { //Declares the motor_spin function. This function spins the motors to the volt value passed in the arguments.
    LeftMotor_group.spin(fwd, L_volt, volt); //Spins the LeftMotor_group to L_volt. fwd is the spinning direction, L_volt is power, volt is units.
    RightMotor_group.spin(fwd, R_volt, volt); //Spins the RightMotor_group to R_volt. fwd is the spinning direction, R_volt is power, volt is units.
}

void motor_reset() { //Declares the motor_reset function. This function resets the motor's position value to 0.
    LeftMotor_group.resetPosition(); //Resets LeftMotor_group's each motor's position (which is stored in degrees spun) to 0.
    RightMotor_group.resetPosition(); //Resets RightMotor_group's each motor's position (which is stored in degrees spun) to 0.
}

void motor_stop(brakeType type = brake) { //Declares the motor-stop function. This function applies brakes of some type to each motor.
    LeftMotor_group.stop(type); //Applies brakes of type to each motor in LeftMotor_group.
    RightMotor_group.stop(type); //Applies brakes of type to each motor in RightMotor_group.
}

double clamp(double value, double minVal, double maxVal) { //Declares the clamp function. This function makes value within range of minVal~maxVal.
    if (value > maxVal) return maxVal; //If value is greater than maxVal, then the function returns maxVal (the maximum value). Return ends the function.
    if (value < minVal) return minVal; //If value is smaller than minVal, then the function returns minVal (the minimum value). Return ends the function.
    return value; //Since if the code runs to this line, it means neither limits were reached, so we can just return the value without any more comparing.
}

void stabilization() { //Declares the stabilization function. This function makes sure no motor is moving before ending.
    while (((LeftMotor_group.velocity(pct) + RightMotor_group.velocity(pct)) / 2) > 1) { //If any motor is moving. Will keep evaluating until reaches false.
        wait (10, msec); //Only runs when condition is true. So this means if any motor is moving, wait 10 milliseconds.
    }
    wait(100, msec); //Waits another 100 milliseconds to ensure nothing is moving. You can decrease this value if you need to save time for autonomous.
}

void turn(double heading, double volt_max = 12, bool stop = true) { //Declares the turn function. This function will turn the robot. The heading variable is the
                                                                    //heading you want your robot to turn to. volt_max is the max volt allowed.
                                                                    //The turn function uses absolute heading, so the heading is relative to the starting heading.
                                                                    //For example, you start facing forward, that is 0 degrees. When you want to turn to the opposite
                                                                    //direction, you input 180 degrees. When you want to turn back again, you input 0 degrees.
    timer limit_time; //Initializes (creates) a timer. This is to measure the time it takes for the movement to finish, if the timer exceeds the timeout, 
                      //then the movement will end. This is to keep the robot moving if it gets stuck.
    limit_time.reset(); //Resets the timer.

    //TUNE THESE VALUES (REFERENCE THE PDF ON HOW TO TUNE)
    double Kp = 1; //Kp is the P value in the PID formula. Reference the PDF for more information.
    double Ki = 0; //Ki is the I value in the PID formula. Reference the PDF for more information.
    double Kd = 1; //Kd is the D value in the PID formula. Reference the PDF for more information.

    double error_INT = 0; //This is the error integral value, it is used in the PID formula. Error integral is the sum of all previous error_now values.
    double error_now = 0; //This is the current error value, it is used in the PID formula. Error now is difference between current and goal heading.
    double error_last = 0; //This is the last error value, it is used in the PID formula. Error last is the previous error_now value.

    motor_reset(); //Resets all the motors distance values.

    double volt_now = 0; //This is the current volt value.

    int count = 0; //Count is used to make sure the robot didn't just reach the destination, overshoot, but tricked the code because it technically reached
                   //the destination. Count makes sure that the robot stays at the destination for a period of time before the function ends.
    
    while(count < 10 && limit_time.time(msec) < 2000) { //The main while loop, only stops after count is greater than 10 or the timeout has been reached.
        double position = Inertial.heading(); //Records the current heading.
        error_now = (heading - position); //Determines the difference between the current and goal heading by goal-current=difference.
        if(error_now > 180) {error_now -= 360;} //Converts the error_now value to a -180~180 range.
        else if(error_now < -180) {error_now += 360;} //Converts the error_now value to a -180~180 range.

        volt_now = clamp(Kp * (error_now) + Ki * error_INT + Kd * (error_now - error_last), -volt_max, volt_max); //PID calculation to determine the volt value.
                                                                                                                  //Uses clamp to make sure volt value does not
                                                                                                                  //exceed volt_max (the volt value limit).
        motor_spin(volt_now, - volt_now); //Executes the turning movement based on the calculated volt. Two sides spin in opposite direction to turn.

        if(fabs(error_now) < 2) {count++;} //Checks if the difference between current and goal heading is smaller than two degrees. If true, increases count.
        else{count = 0;} //If the value exceeds two degrees, reset the count variable. Ensures that the robot is within two degrees for some time.
        error_last = error_now; //Sets the current error to the last error before the loop runs again.
        wait(10, msec); //Wait 10 milliseconds to avoid wasting computing resources. (Could also break connection if value is set too low, speaking from experience.)
    }
    if (stop == false) { //Checks if it should stop
        motor_stop(coast); //If stop = false, then coast.
    } else { //Else follow normal ending procedure.
        motor_stop(brake); //Brakes the motors using the brake type specified.
        stabilization(); //Ensures the robot is stationary.
    }
}

void move(double dis, double heading, double volt_max, double exit_volt = 0, bool stop = true) { //Declares the move function, this function will move the robot.
                                                                                                  //Heading is the orientation of the robot at the end of the
                                                                                                  //movement. It is useful for curved routes, but since curved 
                                                                                                  //routes are very hard to tune, I recommend that you stick to
                                                                                                  //straight line routes. Put heading = 0 for straight line.
    double target = ((dis * 360 * 4)/(wheel_2r * 2.54 * M_PI * 3)); //Converts the distance from centimeters to degrees.
                                                                    //dis / (wheel_2r * 2.54 * M_PI) converts the distance to wheel rotations.
                                                                    //multiplication by 360 converts the rotations to degrees.
                                                                    //4/3 is the gear ratio, this is a PLACEHOLDER, MUST BE CHANGED to match your robot!!!
                                                                    //If you want to reverse the direction of movement, add -1* to the start, so the line becomes
                                                                    //double target = -1*((dis * 360 * 4)/(wheel_2r * 2.54 * M_PI * 3));
    double position_now = 0; //The current movement progress (starts at 0).

    double volt_now = 0; //The current power
    double turn_volt = 0; //The turning power

    double Kp; //Kp is the P value in the PID formula. Reference the PDF for more information.
    double Ki; //Ki is the I value in the PID formula. Reference the PDF for more information.
    double Kd; //Kd is the D value in the PID formula. Reference the PDF for more information.
    double k_turn = 0.7; //k_turn controls how aggressive the heading correction is. Change this value too since 0.7 is just a placeholder.

    if (heading != 0) {k_turn = 3;} //k_turn needs to be a lot more aggressive to achieve curved movement. Change this value too since 3 is just a placeholder.
    else {heading = Inertial.heading();} //If the heading is 0, we set it to the current heading of the robot. Basically telling the robot to maintain current course.

    //TUNE THESE VALUES (REFERENCE THE PDF ON HOW TO TUNE)
    if (volt_max == 12) { //PID set for 12 volt.
        Kp = 1;
        Ki = 0;
        Kd = 1;
    } else if (volt_max == 8) { //PID set for 8 volt.
        Kp = 1;
        Ki = 0;
        Kd = 1;
    } else if (volt_max == 6) { //PID set for 6 volt.
        Kp = 1;
        Ki = 0;
        Kd = 1;
    } else { //Default PID values if volt_max is not equivalent to any of the above conditions.
        Kp = 1;
        Ki = 0;
        Kd = 1;
    }
    //Different volt values can require different PID values. If you do not want to tune many different volt values, you can set them all to one set of PID values, 
    //but it might not be accurate at different volt values. Lower volt values provide more accuracy, while higher volt values can move the robot faster. I do not 
    //recommend using volt_max = 12 because the motor can't spin faster, which causes the code to lose the ability to do heading correction or curved routes.
    
    double distErrorInt = 0; //This is the distance error integral value, it is used in the PID formula. This is the sum of all previous distError values.
    double distErrorPrev = 0; //This is the distance error previous value, it is used in the PID formula. This is the previous distError value.
    double distError; //This is the current distance error value, it is used in the PID formula. This is the difference between the destination and current position.
    double angError; //This is the angular error value, it is used to maintain a straight line or curved route.

    double left_power; //The power provided to the left motor group.
    double right_power; //The power provided to the right motor group.
    motor_reset(); //Resets all the motors distance values.

    timer timeOut; //Initializes (creates) a timer. This is to measure the time it takes for the movement to finish, if the timer exceeds the timeout, 
                   //then the movement will end. This is to keep the robot moving if it gets stuck.
    timeOut.clear(); //Resets the timer.

    while (fabs(position_now) < fabs(target)) { //The main while loop. Checks if target is reached.
        distError = target - position_now; //Calculates the distance between the goal and current position.
        if (fabs(volt_now) < volt_max) { //Only accumulates the integral term when the robot isn't running at the volt limit. This prevents integral windup. For more
                                         //information on PID, reference the PDF guide or go to the Wikipedia PID page, which as an explanation for this phenomenon.
            distErrorInt += distError; //Adds the distance error to the integral.
        }
        if (distError * distErrorPrev < 0) {distErrorInt = 0;} //Checks if an overshoot has occured, if yes, then resets the integral value which prevents accumulated error
                                                               //from one half of the motion from dragging into the other.
        volt_now = (Kp * distError + Ki * distErrorInt + Kd * (distError - distErrorPrev)); //Calculates the volt value using the PID formula.
        
        double volt_min = (exit_volt > 0 && !stop) ? exit_volt : 0; //If exit volt is greater than 0 and stop is false, the minimum volt is set to the exit_volt,
                                                                    //else there is no minimum volt (0).
        if (abs(volt_now) > volt_max) volt_now = copysign(volt_max, volt_now); //If the volt exceeds the volt_max value, then the volt is set to volt_max while
                                                                               //maintaining the sign (+ or -).
        if (position_now >= 0.5 * target) {if (abs(volt_now) < volt_min) volt_now = copysign(volt_min, volt_now);} //Checks if the current position is more than 
                                                                                                                   //halfway to the destination. This is because
                                                                                                                   //the exit_volt is used to regulate the volt
                                                                                                                   //at the end. Since the volt is definitely
                                                                                                                   //at or close to the max at halfway point, 
                                                                                                                   //we can start regulating the minimum volt.
                                                                                                                   //If volt is lower than minimum volt, then
                                                                                                                   //volt is set to volt_min while maintaining
                                                                                                                   //the sign (+ or -).

        angError = heading - Inertial.heading(); //Calculates the angular error, which is the difference in angle between the current and goal heading.
        while (angError > 180) angError -= 360; //Converts the angError value to a -180~180 range.
        while (angError < -180) angError += 360; //Converts the angError value to a -180~180 range.
        turn_volt = angError * k_turn; //Converts the angle error to volts. k_turn is an arbitrary value used to scale the value of turn_volt.
        if (fabs(turn_volt) > volt_now * 0.8) turn_volt = copysign(volt_now * 0.8, turn_volt); //Sets the limit of turn_volt to 80% of the current volt. if
                                                                                               //turn_volt exceeds 80% of volt_now, then it is set to 80% of volt_now.

        left_power  = volt_now + turn_volt; //The volt for the left motor group to turn at, turn_volt's sign is different from right_power to allow turning.
        right_power = volt_now - turn_volt; //The volt for the right motor group to turn at, turn_volt's sign is different from left_power to allow turning.

        left_power  = clamp(left_power, -volt_max, volt_max); //Makes sure volt is within power limit. -volt_max to handle backward movement.
        right_power = clamp(right_power, -volt_max, volt_max); //Makes sure volt is within power limit. -volt_max to handle backward movement.
        motor_spin(left_power, right_power); //Executes the physical movement.

        position_now = (abs(LeftMotor_group.position(deg)) + abs(RightMotor_group.position(deg))) / 2; //Determines the traveled distance by averaging each side's 
                                                                                                       //encoder readings.
        distErrorPrev = distError; //Assigns the current distance error to the previous value before the loop runs again.

        if (timeOut.time(msec) > 7000) break; //Checks if the timeout of 7000 milliseconds is reached, breaks out of the while loop if timeout is reached.
        wait(10, msec); //Wait 10 milliseconds to avoid wasting computing resources. (Could also break connection if value is set too low, speaking from experience.)
    }
    if (stop == false) { //Checks if stopping is required.
        motor_stop(coast); //If exit volt isn't 0, then make the motors coast instead of brake.
    } else { //Else follow normal ending procedure.
        motor_stop(brake); //Brakes the motors using the brake type specified.
        stabilization(); //Ensures the robot is stationary.
    }
}

//THE FOLLOWING IS RPM BASED CONTROL CODE. UNLESS YOU ARE INTERESTED OR RPM CONTROL SOMEHOW BECOMES META, YOU DO NOT NEED TO LEARN THIS------------------------------------
void motor_spin_RPM(double L_speed, double R_speed) { //Declares the motor_spin_RPM function. This function spins the motors to the speed passed in the arguments.
    LeftMotor_group.spin(fwd, L_speed, rpm); //Spins the LeftMotor_group to L_speed. fwd is the spinning direction, L_speed is speed, rpm is units.
    RightMotor_group.spin(fwd, R_speed, rpm); //Spins the RightMotor_group to R_speed. fwd is the spinning direction, R_speed is speed, rpm is units.
}

void turnRPM(double heading, double speed_max = 300, bool stop = true) { //Declares the turnRPM function. This function will turn the robot. The heading variable 
                                                                         //is the heading you want your robot to turn to. speed_max is the max speed allowed.
                                                                         //The turnRPM function uses absolute heading, so the heading is relative to the starting heading.
                                                                         //For example, you start facing forward, that is 0 degrees. When you want to turn to the opposite
                                                                         //direction, you input 180 degrees. When you want to turn back again, you input 0 degrees.
    timer limit_time; //Initializes (creates) a timer. This is to measure the time it takes for the movement to finish, if the timer exceeds the timeout, 
                      //then the movement will end. This is to keep the robot moving if it gets stuck.
    limit_time.reset(); //Resets the timer.

    //TUNE THESE VALUES (REFERENCE THE PDF ON HOW TO TUNE)
    double Kp = 1; //Kp is the P value in the PID formula. Reference the PDF for more information.
    double Ki = 0; //Ki is the I value in the PID formula. Reference the PDF for more information.
    double Kd = 1; //Kd is the D value in the PID formula. Reference the PDF for more information.

    double error_INT = 0; //This is the error integral value, it is used in the PID formula. Error integral is the sum of all previous error_now values.
    double error_now = 0; //This is the current error value, it is used in the PID formula. Error now is difference between current and goal heading.
    double error_last = 0; //This is the last error value, it is used in the PID formula. Error last is the previous error_now value.

    motor_reset(); //Resets all the motors distance values.

    double speed_now = 0; //This is the current speed value.

    int count = 0; //Count is used to make sure the robot didn't just reach the destination, overshoot, but tricked the code because it technically reached
                   //the destination. Count makes sure that the robot stays at the destination for a period of time before the function ends.

    while(count < 10 && limit_time.time(msec) < 2000) { //The main while loop, only stops after count is greater than 10 or the timeout has been reached.
        double position = Inertial.heading(); //Records the current heading.
        error_now = (heading - position); //Determines the difference between the current and goal heading by goal-current=difference.
        if(error_now > 180) {error_now -= 360;} //Converts the error_now value to a -180~180 range.
        else if(error_now < -180) {error_now += 360;} //Converts the error_now value to a -180~180 range.

        speed_now = clamp(Kp * (error_now) + Ki * error_INT + Kd * (error_now - error_last), -speed_max, speed_max); //PID calculation to determine the speed.
                                                                                                                     //Uses clamp to make sure speed does not
                                                                                                                     //exceed speed_max (the speed limit).
        motor_spin_RPM(speed_now, - speed_now); //Executes the turning movement based on the calculated speed. Two sides spin in opposite direction to turn.

        if(fabs(error_now) < 2) {count++;} //Checks if the difference between current and goal heading is smaller than two degrees. If true, increases count.
        else{count = 0;} //If the value exceeds two degrees, reset the count variable. Ensures that the robot is within two degrees for some time.
        error_last = error_now; //Sets the current error to the last error before the loop runs again.
        wait(10, msec); //Wait 10 milliseconds to avoid wasting computing resources. (Could also break connection if value is set too low, speaking from experience.)
    }
    if (stop == false) { //Checks if it should stop
        motor_stop(coast); //If stop = false, then coast.
    } else { //Else follow normal ending procedure.
        motor_stop(brake); //Brakes the motors using the brake type specified.
        stabilization(); //Ensures the robot is stationary.
    }
}

void moveRPM(double dis, double heading, double speed_max, double exit_speed = 0, bool stop = true) { //Declares the moveRPM function, this function will move the robot.
                                                                                                      //Heading is the orientation of the robot at the end of the
                                                                                                      //movement. It is useful for curved routes, but since curved 
                                                                                                      //routes are very hard to tune, I recommend that you stick to
                                                                                                      //straight line routes. Put heading = 0 for straight line.
    double target = ((dis * 360 * 4)/(wheel_2r * 2.54 * M_PI * 3)); //Converts the distance from centimeters to degrees.
                                                                    //dis / (wheel_2r * 2.54 * M_PI) converts the distance to wheel rotations.
                                                                    //multiplication by 360 converts the rotations to degrees.
                                                                    //4/3 is the gear ratio, this is a PLACEHOLDER, MUST BE CHANGED to match your robot!!!
                                                                    //If you want to reverse the direction of movement, add -1* to the start, so the line becomes
                                                                    //double target = -1*((dis * 360 * 4)/(wheel_2r * 2.54 * M_PI * 3));
    double position_now = 0; //The current movement progress (starts at 0).

    double speed_now = 0; //The current speed
    double turn_speed = 0; //The turning speed

    double Kp; //Kp is the P value in the PID formula. Reference the PDF for more information.
    double Ki; //Ki is the I value in the PID formula. Reference the PDF for more information.
    double Kd; //Kd is the D value in the PID formula. Reference the PDF for more information.
    double k_turn = 0.7; //k_turn controls how aggressive the heading correction is. Feel free to change this value too.

    if (heading != 0) {k_turn = 3;} //k_turn needs to be a lot more aggressive to achieve curved movement. Change this value too since 3 is just a placeholder.
    else {heading = Inertial.heading();} //If the heading is 0, we set it to the current heading of the robot. Basically telling the robot to maintain current course.

    //TUNE THESE VALUES (REFERENCE THE PDF ON HOW TO TUNE)
    if (speed_max == 600) { //PID set for 600 RPM.
        Kp = 1;
        Ki = 0;
        Kd = 1;
    } else if (speed_max == 400) { //PID set for 400 RPM.
        Kp = 1;
        Ki = 0;
        Kd = 1;
    } else if (speed_max == 200) { //PID set for 200 RPM.
        Kp = 1;
        Ki = 0;
        Kd = 1;
    } else { //Default PID values if speed_max is not equivalent to any of the above conditions.
        Kp = 1;
        Ki = 0;
        Kd = 1;
    }
    //Different speeds can require different PID values. If you do not want to tune many different speeds, you can set them all to one set of PID values, but it might
    //not be accurate at different speeds. Lower speeds provide more accuracy, while higher speeds can move the robot faster. The RPM here also isn't the actual wheel
    //RPM, but simply the motor RPM. I do not recommend using speed_max = 600 because the motor can't spin faster, which causes the code to lose the ability to do
    //heading correction or curved routes.
    
    double distErrorInt = 0; //This is the distance error integral value, it is used in the PID formula. This is the sum of all previous distError values.
    double distErrorPrev = 0; //This is the distance error previous value, it is used in the PID formula. This is the previous distError value.
    double distError; //This is the current distance error value, it is used in the PID formula. This is the difference between the destination and current position.
    double angError; //This is the angular error value, it is used to maintain a straight line or curved route.

    double left_power; //The RPM provided to the left motor group.
    double right_power; //The RPM provided to the right motor group.
    motor_reset(); //Resets all the motors distance values.

    timer timeOut; //Initializes (creates) a timer. This is to measure the time it takes for the movement to finish, if the timer exceeds the timeout, 
                   //then the movement will end. This is to keep the robot moving if it gets stuck.
    timeOut.clear(); //Resets the timer.

    while (fabs(position_now) < fabs(target)) { //The main while loop. Checks if target is reached.
        distError = target - position_now; //Calculates the distance between the goal and current position.
        if (fabs(speed_now) < speed_max) { //Only accumulates the integral term when the robot isn't running at the RPM limit. This prevents integral windup. For more
                                           //information on PID, reference the PDF guide or go to the Wikipedia PID page, which as an explanation for this phenomenon.
            distErrorInt += distError; //Adds the distance error to the integral.
        }
        if (distError * distErrorPrev < 0) {distErrorInt = 0;} //Checks if an overshoot has occured, if yes, then resets the integral value which prevents accumulated error
                                                               //from one half of the motion from dragging into the other.
        speed_now = (Kp * distError + Ki * distErrorInt + Kd * (distError - distErrorPrev)); //Calculates the speed using the PID formula.
        
        double speed_min = (exit_speed > 0 && !stop) ? exit_speed : 0; //If exit speed is greater than 0 and stop is false, the minimum speed is set to the exit_speed,
                                                                       //else there is no minimum speed (0).
        if (abs(speed_now) > speed_max) speed_now = copysign(speed_max, speed_now); //If the speed exceeds the speed_max value, then the speed is set to speed_max while
                                                                                    //maintaining the sign (+ or -).
        if (position_now >= 0.5 * target) {if (abs(speed_now) < speed_min) speed_now = copysign(speed_min, speed_now);} //Checks if the current position is more than 
                                                                                                                        //halfway to the destination. This is because
                                                                                                                        //the exit_speed is used to regulate the speed
                                                                                                                        //at the end. Since the speed is definitely
                                                                                                                        //at or close to the max at halfway point, 
                                                                                                                        //we can start regulating the minimum speed.
                                                                                                                        //If speed is lower than minimum speed, then
                                                                                                                        //speed is set to speed_min while maintaining
                                                                                                                        //the sign (+ or -).

        angError = heading - Inertial.heading(); //Calculates the angular error, which is the difference in angle between the current and goal heading.
        while (angError > 180) angError -= 360; //Converts the angError value to a -180~180 range.
        while (angError < -180) angError += 360; //Converts the angError value to a -180~180 range.
        turn_speed = angError * k_turn; //Converts the angle error to RPM. k_turn is an arbitrary value used to scale the value of turn_speed.
        if (fabs(turn_speed) > speed_now * 0.8) turn_speed = copysign(speed_now * 0.8, turn_speed); //Sets the limit of turn_speed to 80% of the current speed. if
                                                                                                    //turn_speed exceeds 80% of speed_now, then it is set to 80% of
                                                                                                    //speed_now.

        left_power  = speed_now + turn_speed; //The speed for the left motor group to turn at, turn_speed's sign is different from right_power to allow turning.
        right_power = speed_now - turn_speed; //The speed for the right motor group to turn at, turn_speed's sign is different from left_power to allow turning.

        left_power  = clamp(left_power, -speed_max, speed_max); //Makes sure speed is within speed limit. -speed_max to handle backward movement.
        right_power = clamp(right_power, -speed_max, speed_max); //Makes sure speed is within speed limit. -speed_max to handle backward movement.
        motor_spin_RPM(left_power, right_power); //Executes the physical movement.

        position_now = (abs(LeftMotor_group.position(deg)) + abs(RightMotor_group.position(deg))) / 2; //Determines the traveled distance by averaging each side's 
                                                                                                       //encoder readings.
        distErrorPrev = distError; //Assigns the current distance error to the previous value before the loop runs again.

        if (timeOut.time(msec) > 7000) break; //Checks if the timeout of 7000 milliseconds is reached, breaks out of the while loop if timeout is reached.
        wait(10, msec); //Wait 10 milliseconds to avoid wasting computing resources. (Could also break connection if value is set too low, speaking from experience.)
    }
    if (stop == false) { //Checks if stopping is required.
        motor_stop(coast); //If exit speed isn't 0, then make the motors coast instead of brake.
    } else { //Else follow normal ending procedure.
        motor_stop(brake); //Brakes the motors using the brake type specified.
        stabilization(); //Ensures the robot is stationary.
    }
}

//TROUBLESHOOTING----------------------------------------------------------------------------------------------------------------------------------------------
/*
Q: I have been tuning the PID for a very long time but it still isn't accurate
A: It takes some time to properly tune the PID. If you haven't reached a usable PID after tuning for hours, you should consider asking online forums or
   on the Github issues page.

Q: In between two move functions I have to turn a small amount, is it possible to make it not stop in between
A: You have two options:
    1: Combine the two movement into one movement and utilize the heading argument. This will result in a curved route instead of a combination of two straight
       lines, but the ending position would be similar.
    2: Use the exit_volt argument in the move function. First set the exit_volt of the first one to your desired speed (slower speed will result in a more 
       accurate turn), then execute a turn function with stop = false argument, then use another move function. The distance traveled using this way could be 
       inaccurate, so it would require changing the travel distance argument even if your PID is perfect.

Q: Under what circumstances should I use the RPM functions
A: If there is a widespread consensus online that RPM control is suddenly meta, use them. Else, don't.

Q: My problem is not in the troubleshooting section
A: Go to the GitHub repository, click on the "Issues" tab, and submit a new issue describing your problem. I will respond.
*/