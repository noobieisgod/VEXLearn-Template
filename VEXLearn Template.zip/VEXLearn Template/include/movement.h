//INTRODUCTION-------------------------------------------------------------------------------------------------------------------------------------------------
/*
This is the header file for movement.cpp. For more explanation on what header files are, check the PDF.
*/

//STRUCTURE EXPLANATION----------------------------------------------------------------------------------------------------------------------------------------
/*
The format for writing a function in a header file is:

return_type function_name(arguments);

It is VERY IMPORTANT that your return_type function_name(arguments) are identical to those in movement.cpp. A quick way to write this is to copy the
function declaration line from movement.cpp then removing the { bracket, then adding a semicolon (;) to the end of it.
*/

//CODE---------------------------------------------------------------------------------------------------------------------------------------------------------
#pragma once //This prevents the duplication of the header file when included multiple times. For more information, reference the PDF file. Should be supported
             //by any modern compiler.

void turn(double heading, double volt_max = 12, bool stop = true);
void move(double dis, double heading, double volt_max, double exit_volt = 0, bool stop = true);
void turnRPM(double heading, double speed_max = 300, bool stop = true);
void moveRPM(double dis, double heading, double speed_max, double exit_speed = 0, bool stop = true);

//TROUBLESHOOTING----------------------------------------------------------------------------------------------------------------------------------------------
/*
Q: I can't access the movement functions in another file
A: Make sure you have added your movement function to the header file. Make sure the header file is included in the file you are working on, if it isn't, add 
   "#include "movement.h" into the file. Make sure your spelling for the function name is correct and identical in movement.cpp, movement.h, and the file.

Q: My problem is not in the troubleshooting section
A: Go to the GitHub repository, click on the "Issues" tab, and submit a new issue describing your problem. I will respond.
*/