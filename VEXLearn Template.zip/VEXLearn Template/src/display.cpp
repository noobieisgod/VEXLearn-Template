//INTRODUCTION-------------------------------------------------------------------------------------------------------------------------------------------------
/*
The display.cpp file contains the functions for the brain and controller display. The BrainRender function is what is called in main.cpp to render the brain 
display, and the ControllerRender function is what is called in main.cpp to render the controller display. You can customize what is displayed on the brain 
and controller by changing the contents of these functions. You can also add more functions if you want to display different things on the brain and controller,
but make sure to call those functions in main.cpp as well.
*/

//STRUCTURE EXPLANATION----------------------------------------------------------------------------------------------------------------------------------------
/*
The display functions use an infinite loop to continuously update the display, and they use the screen's setCursor, clearScreen, print, and newLine functions 
to display information. You can use the screen's setFont and setPenColor functions to change the font and color of the text. The ControllerRender function 
displays the heading, temperature, and battery percentage on the controller screen. The MainMenu function displays various information on the brain screen 
and has buttons for different screens. You can customize what is displayed and how it looks by changing the code in these functions.
*/

//CODE---------------------------------------------------------------------------------------------------------------------------------------------------------
#include "robotConfig.h" //Includes the robotConfig header file so you can use motor functions.

enum ScreenState {MENU, MOTORS, BATTERY, TEAM, SOFTWARE}; //See PDF file for explanation on what enum is. Declares screen states for future use.
ScreenState currentScreen = MENU; //The display OS starts with the menu screen.

void ControllerRender() { //The controller screen render function
    while (true) { //Infinite loop
        double temperature = ((LeftMotor1.temperature() + LeftMotor2.temperature() + LeftMotor3.temperature()
                              + RightMotor1.temperature() + RightMotor2.temperature() + RightMotor3.temperature()
                             ) / 6); //temperature = average motor temperatures

        Controller1.Screen.setCursor(1, 1); //Text starts at row 1 column 1 of text grid.
        Controller1.Screen.clearScreen(); //Clears anything on screen.
        Controller1.Screen.print("Heading: %.1f°", Inertial.heading()); //Prints heading on screen.
        Controller1.Screen.newLine(); //Prints new line.
        Controller1.Screen.print("Temperature: %.1f°", temperature); //Prints average motor temperature on screen.
        Controller1.Screen.newLine(); //Prints new line.
        Controller1.Screen.print("Battery: %d%", Brain.Battery.capacity()); //Prints the remaining battery capacity on screen.

        wait(100, msec); //Wait 0.1 second before refreshing screen. Making the display 10 hz.
    }
}

void MainMenu() { //The main menu screen.
    Brain.Screen.setOrigin(0,0); //Sets coordinates 0,0 to be origin.

    wait (0.1, sec); //Wait to avoid screen refresh before finger lifts, resulting in going back to another screen.
    
    while (true) { //Infinite loop
        double touchX; //Variable to contain x coordinate of touch.
        double touchY; //Variable to contain y coordinate of touch.
        
        Brain.Screen.setCursor(1,1); //Text starts at row 1 column 1 of text grid.
        Brain.Screen.setFont(monoM); //Set font size.
        Brain.Screen.setPenColor(white); //Set text color.

        //The following is the contents of the main menu screen, the code itself is pretty self-explanatory. Copy paste anything you don't understand into AI
        //and it will do a pretty good job of explaining it.
        Brain.Screen.print("--------------------Main Menu-------------------");
        Brain.Screen.newLine();
        Brain.Screen.print("Developed by noobieisgod 2026, all rights reserved.");
        Brain.Screen.newLine();
        Brain.Screen.print("------------------------------------------------");
        Brain.Screen.newLine();
        Brain.Screen.print("Battery Remaining: ");
        Brain.Screen.print(Brain.Battery.capacity());
        Brain.Screen.print(" percent");
        Brain.Screen.newLine();
        Brain.Screen.print("Battery Temperature: %.1f°C", Brain.Battery.temperature());
        Brain.Screen.newLine();
        Brain.Screen.print("Battery Draw: %.2fA", Brain.Battery.current());
        Brain.Screen.newLine();
        Brain.Screen.print("------------------------------------------------");
        Brain.Screen.newLine();
        if (Brain.SDcard.isInserted()) {
            Brain.Screen.print("SD Card Status: Inserted");
        } else {
            Brain.Screen.print("SD Card Status: Not Inserted");
        }
        Brain.Screen.newLine();
        Brain.Screen.print("Inertial Heading: %.0f", Inertial.heading());
        Brain.Screen.newLine();
        Brain.Screen.print("Software Version: 1.36");
        
        //Draws the buttons
        Brain.Screen.drawRectangle(0,200, 120, 40, blue);
        Brain.Screen.drawRectangle(120,200, 120, 40, red);
        Brain.Screen.drawRectangle(240,200, 120, 40, green);
        Brain.Screen.drawRectangle(360,200, 120, 40, purple);
        
        //Gives the buttons text
        Brain.Screen.printAt(30, 225, "Motors");
        Brain.Screen.printAt(145, 225, "Battery");
        Brain.Screen.printAt(280, 225, "Team");
        Brain.Screen.printAt(380, 225, "Software");

        if (Brain.Screen.pressing() == true) { //Detects if brain screen is touched
            touchX=Brain.Screen.xPosition(); //Records x coordinate of touch
            touchY=Brain.Screen.yPosition(); //Records y coordinate of touch

            if (touchX > 0 && touchX < 120 && touchY > 200 && touchY < 240) { //Determines if touch is on a button
                currentScreen = MOTORS; //Change the screen to the button's screen
                touchX = 0; //Reset variable
                touchY = 0; //Reset variable
                break; //Break from loop
            } else if (touchX > 120 && touchX < 240 && touchY > 200 && touchY < 240) { //Determines if touch is on a button
                currentScreen = BATTERY; //Change the screen to the button's screen
                touchX = 0; //Reset variable
                touchY = 0; //Reset variable
                break; //Break from loop
            } else if (touchX > 240 && touchX < 360 && touchY > 200 && touchY < 240) { //Determines if touch is on a button
                currentScreen = TEAM; //Change the screen to the button's screen
                touchX = 0; //Reset variable
                touchY = 0; //Reset variable
                break; //Break from loop
            } else if (touchX > 360 && touchX < 480 && touchY > 200 && touchY < 240) { //Determines if touch is on a button
                currentScreen = SOFTWARE; //Change the screen to the button's screen
                touchX = 0; //Reset variable
                touchY = 0; //Reset variable
                break; //Break from loop
            } else { //Didn't touch any of the buttons
                currentScreen = MENU; //Screen shows the same menu
                touchX = 0; //Reset variable
                touchY = 0; //Reset variable
                break; //Break from loop
            }
        }
        wait(100, msec); //Wait 0.1 second before refreshing screen. Making the display 10 hz.
    } 
}

void Motors() { //The motor screen.
    Brain.Screen.setOrigin(0,0); //Sets 0,0 as the origin.
    Brain.Screen.setFont(monoS); //Set font size.
    Brain.Screen.setPenColor(white); //Set text color.

    wait (0.1, sec); //Wait to avoid screen refresh before finger lifts, resulting in going back to another screen.

    while (true) {
        double touchX; //Variable to contain x coordinate of touch.
        double touchY; //Variable to contain y coordinate of touch.
        
        //Printing the velocity, temperature, and voltage information of each motor.
        Brain.Screen.setCursor(1,1);
        Brain.Screen.print("Left Motor 1: ");
        Brain.Screen.newLine();
        Brain.Screen.print("    Velocity: ");
        Brain.Screen.print(LeftMotor1.velocity(rpm));
        Brain.Screen.print("RPM");
        Brain.Screen.newLine();
        Brain.Screen.print("    Temperature: ");
        Brain.Screen.print(LeftMotor1.temperature());
        Brain.Screen.print("°C");
        Brain.Screen.newLine();
        Brain.Screen.print("    Voltage: ");
        Brain.Screen.print(LeftMotor1.voltage());
        Brain.Screen.print("v");
        Brain.Screen.newLine();

        Brain.Screen.print("Left Motor 2: ");
        Brain.Screen.newLine();
        Brain.Screen.print("    Velocity: ");
        Brain.Screen.print(LeftMotor2.velocity(rpm));
        Brain.Screen.print("RPM");
        Brain.Screen.newLine();
        Brain.Screen.print("    Temperature: ");
        Brain.Screen.print(LeftMotor2.temperature());
        Brain.Screen.print("°C");
        Brain.Screen.newLine();
        Brain.Screen.print("    Voltage: ");
        Brain.Screen.print(LeftMotor2.voltage());
        Brain.Screen.print("v");
        Brain.Screen.newLine();

        Brain.Screen.print("Left Motor 3: ");
        Brain.Screen.newLine();
        Brain.Screen.print("    Velocity: ");
        Brain.Screen.print(LeftMotor3.velocity(rpm));
        Brain.Screen.print("RPM");
        Brain.Screen.newLine();
        Brain.Screen.print("    Temperature: ");
        Brain.Screen.print(LeftMotor3.temperature());
        Brain.Screen.print("°C");
        Brain.Screen.newLine();
        Brain.Screen.print("    Voltage: ");
        Brain.Screen.print(LeftMotor3.voltage());
        Brain.Screen.print("v");

        Brain.Screen.setOrigin(240, 0);
        Brain.Screen.print("Right Motor 1: ");
        Brain.Screen.newLine();
        Brain.Screen.print("    Velocity: ");
        Brain.Screen.print(RightMotor1.velocity(rpm));
        Brain.Screen.print("RPM");
        Brain.Screen.newLine();
        Brain.Screen.print("    Temperature: ");
        Brain.Screen.print(RightMotor1.temperature());
        Brain.Screen.print("°C");
        Brain.Screen.newLine();
        Brain.Screen.print("    Voltage: ");
        Brain.Screen.print(RightMotor1.voltage());
        Brain.Screen.print("v");
        Brain.Screen.newLine();

        Brain.Screen.print("Right Motor 2: ");
        Brain.Screen.newLine();
        Brain.Screen.print("    Velocity: ");
        Brain.Screen.print(RightMotor2.velocity(rpm));
        Brain.Screen.print("RPM");
        Brain.Screen.newLine();
        Brain.Screen.print("    Temperature: ");
        Brain.Screen.print(RightMotor2.temperature());
        Brain.Screen.print("°C");
        Brain.Screen.newLine();
        Brain.Screen.print("    Voltage: ");
        Brain.Screen.print(RightMotor2.voltage());
        Brain.Screen.print("v");
        Brain.Screen.newLine();

        Brain.Screen.print("Right Motor 3: ");
        Brain.Screen.newLine();
        Brain.Screen.print("    Velocity: ");
        Brain.Screen.print(RightMotor3.velocity(rpm));
        Brain.Screen.print("RPM");
        Brain.Screen.newLine();
        Brain.Screen.print("    Temperature: ");
        Brain.Screen.print(RightMotor3.temperature());
        Brain.Screen.print("°C");
        Brain.Screen.newLine();
        Brain.Screen.print("    Voltage: ");
        Brain.Screen.print(RightMotor3.voltage());
        Brain.Screen.print("v");
        Brain.Screen.newLine();

        //Printing the velocity, temperature, and voltage information of side of the chassis.
        Brain.Screen.setOrigin(190, 210);
        Brain.Screen.print("Left Motor RPM Average: ");
        Brain.Screen.print((LeftMotor1.velocity(rpm) + LeftMotor2.velocity(rpm) + LeftMotor3.velocity(rpm)) / 3);
        Brain.Screen.print("RPM");
        Brain.Screen.newLine();
        Brain.Screen.print("Right Motor RPM Average: ");
        Brain.Screen.print((RightMotor1.velocity(rpm) + RightMotor2.velocity(rpm) + RightMotor3.velocity(rpm)) / 3);
        Brain.Screen.print("RPM");

        Brain.Screen.setOrigin(0, 0); //Resets the origin back to 0,0
        Brain.Screen.drawRectangle(0, 200, 175, 40, red); //Draw the return to menu button
        Brain.Screen.printAt(30, 225, "Return to Menu"); //Button text

        if (Brain.Screen.pressing() == true) { //Detects touch
            touchX=Brain.Screen.xPosition(); //Stores touch x coordinate
            touchY=Brain.Screen.yPosition(); //Stores touch y coordinate

            if (touchX > 0 && touchX < 175 && touchY > 200 && touchY < 240) { //Check if button is touched
                currentScreen = MENU; //Return to menu if true
                touchX = 0; //reset variable
                touchY = 0; //reset variable
                break; //Break from loop
            } else { //Remain on the same screen
                touchX = 0; //reset variable
                touchY = 0; //reset variable
                break; //Break from loop
            }
        }
        wait(0.1, sec); //Wait 0.1 second before refreshing screen. Making the display 10 hz.
    }
}

void Battery() { //Page showing battery information
    Brain.Screen.setOrigin(0,0); //Sets 0,0 as the origin.
    Brain.Screen.setPenColor(white); //Set text color.

    wait (0.1, sec); //Wait to avoid screen refresh before finger lifts, resulting in going back to another screen.

    while (true) {
        Brain.Screen.setFont(monoL);
        double touchX; //Variable to contain x coordinate of touch.
        double touchY; //Variable to contain y coordinate of touch.

        //Printing battery charge remaining, voltage, draw, and temperature
        Brain.Screen.setCursor(1,1);
        Brain.Screen.print("Battery Info: ");
        Brain.Screen.newLine();
        Brain.Screen.print("    Charge Remaining: ");
        Brain.Screen.print(Brain.Battery.capacity());
        Brain.Screen.print("%");
        Brain.Screen.newLine();
        Brain.Screen.print("    Voltage: ");
        Brain.Screen.print(Brain.Battery.voltage());
        Brain.Screen.print("v");
        Brain.Screen.newLine();
        Brain.Screen.print("    Total Draw: ");
        Brain.Screen.print(Brain.Battery.current());
        Brain.Screen.print("A");
        Brain.Screen.newLine();
        Brain.Screen.print("    Temperature: ");
        Brain.Screen.print(Brain.Battery.temperature());
        Brain.Screen.print("°C");

        //The same return to menu button mechanism
        Brain.Screen.setFont(monoS);
        Brain.Screen.drawRectangle(0, 200, 175, 40, red);
        Brain.Screen.printAt(30, 225, "Return to Menu");

        if (Brain.Screen.pressing() == true) {
            touchX=Brain.Screen.xPosition();
            touchY=Brain.Screen.yPosition();

            if (touchX > 0 && touchX < 175 && touchY > 200 && touchY < 240) {
                currentScreen = MENU;
                touchX = 0;
                touchY = 0;
                break;
            } else {
                touchX = 0;
                touchY = 0;
                break;
            }
        }
        wait(0.1, sec); //Wait 0.1 second before refreshing screen. Making the display 10 hz.
    }
}

void Team() { //Team tab, mostly a gimmick to show to judges during interviews.
    Brain.Screen.setOrigin(0,0); //Sets 0,0 as the origin.
    Brain.Screen.setPenColor(white); //Set text color.

    wait (0.1, sec); //Wait to avoid screen refresh before finger lifts, resulting in going back to another screen.

    while (true) {
        double touchX; //Variable to contain x coordinate of touch.
        double touchY; //Variable to contain y coordinate of touch.

        Brain.Screen.setFont(monoXS); //Set font size
        Brain.Screen.setCursor(1,1); //Sets text to start be printed at row 1 column 1 of text grid.

        Brain.Screen.print("Team: Team_name Team_number");
        Brain.Screen.newLine();
        Brain.Screen.print("Members: Austin, Frank, and Eric");
        Brain.Screen.newLine();
        Brain.Screen.newLine();
        Brain.Screen.print("Name: Role");
        Brain.Screen.newLine();
        Brain.Screen.print("description description description description description------");
        Brain.Screen.newLine();
        Brain.Screen.print("description description description description description------");
        Brain.Screen.newLine();
        Brain.Screen.print("description description description description description------");
        Brain.Screen.newLine();
        Brain.Screen.newLine();
        Brain.Screen.print("Name: Role");
        Brain.Screen.newLine();
        Brain.Screen.print("description description description description description------");
        Brain.Screen.newLine();
        Brain.Screen.print("description description description description description------");
        Brain.Screen.newLine();
        Brain.Screen.print("description description description description description------");
        Brain.Screen.newLine();
        Brain.Screen.newLine();
        Brain.Screen.print("Name: Role");
        Brain.Screen.newLine();
        Brain.Screen.print("description description description description description------");
        Brain.Screen.newLine();
        Brain.Screen.print("description description description description description------");
        Brain.Screen.newLine();
        Brain.Screen.print("description description description description description------");

        //The same return to menu button mechanism
        Brain.Screen.setFont(monoS);
        Brain.Screen.drawRectangle(0, 210, 175, 40, red);
        Brain.Screen.printAt(30, 230, "Return to Menu");

        if (Brain.Screen.pressing() == true) {
            touchX=Brain.Screen.xPosition();
            touchY=Brain.Screen.yPosition();

            if (touchX > 0 && touchX < 175 && touchY > 210 && touchY < 240) {
                currentScreen = MENU;
                touchX = 0;
                touchY = 0;
                break;
            } else {
                touchX = 0;
                touchY = 0;
                break;
            }
        }
        wait(0.1, sec); //Wait 0.1 second before refreshing screen. Making the display 10 hz.
    }
}

void Software() { //A placeholder tab, feel free to change this to display anything you want.
    Brain.Screen.setOrigin(0,0); //Sets 0,0 as the origin.
    Brain.Screen.setPenColor(white); //Set text color.

    wait (0.1, sec); //Wait to avoid screen refresh before finger lifts, resulting in going back to another screen.

    while (true) {
        double touchX; //Variable to contain x coordinate of touch.
        double touchY; //Variable to contain y coordinate of touch.

        //Developer and other information
        Brain.Screen.setCursor(1,1);
        Brain.Screen.setFont(monoM);
        Brain.Screen.print("THE VEXLearn Template");
        Brain.Screen.newLine();
        Brain.Screen.print("Software developed by noobieisgod 2026.");
        Brain.Screen.newLine();
        Brain.Screen.print("Written in Visual Studio Code with C++.");

        //The same return to menu button mechanism
        Brain.Screen.setFont(monoS);
        Brain.Screen.drawRectangle(0, 200, 175, 40, red);
        Brain.Screen.printAt(30, 225, "Return to Menu");

        if (Brain.Screen.pressing() == true) {
            touchX=Brain.Screen.xPosition();
            touchY=Brain.Screen.yPosition();

            if (touchX > 0 && touchX < 175 && touchY > 200 && touchY < 240) {
                currentScreen = MENU;
                touchX = 0;
                touchY = 0;
                break;
            } else {
                touchX = 0;
                touchY = 0;
                break;
            }
        }
        wait(0.1, sec); //Wait 0.1 second before refreshing screen. Making the display 10 hz.
    }
}

//Each time the screen is touched, the break statement is executed regardless if it is on the Back to Menu button or not. This means tapping anywhere
//on the screen acts like a screen refresh. This is fine in practice but is worth telling you so you don't get confused.
void BrainRender() { //The brain screen render function.
    while (true) { //Infinite loop
        Brain.Screen.clearScreen(); //Clears everything on screen
        switch (currentScreen) { //Switch statement with the current screen variable as argument
            case MENU: //Display screen based on currentScreen's value.
                MainMenu(); //Display
                break; //Break from loop
            case MOTORS: //Display screen based on currentScreen's value.
                Motors(); //Display
                break; //Break from loop
            case BATTERY: //Display screen based on currentScreen's value.
                Battery(); //Display
                break; //Break from loop
            case TEAM: //Display screen based on currentScreen's value.
                Team(); //Display
                break; //Break from loop
            case SOFTWARE: //Display screen based on currentScreen's value.
                Software(); //Display
                break; //Break from loop
        }
    }
}