//INTRODUCTION-------------------------------------------------------------------------------------------------------------------------------------------------
/*
MORE SPECIFIC EXPLANATIONS AND TIPS ARE IN THE PDF FILE!
The robot configuration file is where you initialize the parts of your robot. The parts you have to initialize include: brain, controller, motors, and any
sensor you're using. It is best that you write this file with your builder so you can ask him any question you encounter.
*/

//STRUCTURE EXPLANATION----------------------------------------------------------------------------------------------------------------------------------------
/*
Your robotConfig.cpp will start by including vex.h, this is because it includes the brain, controller, motors, etc. datatypes. Include follows this format:

#include whatever_file

In this file's case it would be:

#include "vex.h"

Brain initialization follows this format:

brain Brain_name;

Controller initialization follows this format:

controller Controller_name = controller(primary);

This indicates that the controller is the primary controller.

12 watt motor initialization follows this format:

motor Motor_name = motor(port_number, gear_ratio, direction);

For port_number, it is PORT then whatever port number the motor is connected to on the brain. For example, port 1 is PORT1 and port 15 is PORT15. For direction,
false is the default where clockwise rotation is treated as forward (positive direction), true is where counterclockwise rotation is treated as forward (positive
direction). For gear_ratio, red is 36:1 (ratio36_1), green is 18:1 (ratio18_1), and blue is 6:1 (ratio6_1).

6 watt motor initialization follows this format:

motor Motor_name = motor(port_number, direction);

Inertial sensor initialization follows this format:

inertial Inertial_name = inertial(port_number);

Distance sensor initialization follows this format:

distance DistanceSensor_name = distance(port_number);

Piston initialization follows this format:

digital_out Piston_name = digital_out(threeWirePort_letter);

For three wire port, it is Brain.ThreeWirePort.letter. For example port A is Brain.ThreeWirePort.A and port D is Brain.ThreeWirePort.D.

Motor group initialization follows this format:

motor_group motorGroup_name(motor, motor, motor);

There is no limit to how many motors can be in a motor group. The purpose of a motor group is to allow for control over multiple motors doing the same thing.
*/

//CODE---------------------------------------------------------------------------------------------------------------------------------------------------------
#include "vex.h" //Needed for datatype. No need to change this.

using namespace vex; //All functions are using the namespace vex (basically version of function). No need to change this.

brain Brain; //Example brain initialization.

controller Controller1 = controller(primary); //Example controller initialization.

motor LeftMotor1 = motor(PORT1, ratio6_1, true); //Example 12 watt motor initialization.
motor LeftMotor2 = motor(PORT2, ratio6_1, true); //Example 12 watt motor initialization.
motor LeftMotor3 = motor(PORT3, ratio6_1, true); //Example 12 watt motor initialization.
motor RightMotor1 = motor(PORT4, ratio6_1, false); //Example 12 watt motor initialization.
motor RightMotor2 = motor(PORT5, ratio6_1, false); //Example 12 watt motor initialization.
motor RightMotor3 = motor(PORT6, ratio6_1, false); //Example 12 watt motor initialization.
motor FrontMotor = motor(PORT7, false); //Example 6 watt motor initialization.
motor BackMotor = motor(PORT8, false); //Example 6 watt motor initialization.

inertial Inertial = inertial(PORT9); //Example inertial sensor initialization.
distance DistanceSensor = distance(PORT10); //Example distance sensor initialization.
digital_out Pistons = digital_out(Brain.ThreeWirePort.D); //Example piston initialization.
digital_out Pistons2 = digital_out(Brain.ThreeWirePort.C); //Example piston initialization.

motor_group LeftMotor_group(LeftMotor1, LeftMotor2, LeftMotor3); //Example motor group initialization.
motor_group RightMotor_group(RightMotor1, RightMotor2, RightMotor3); //Example motor group initialization.

//DO NOT CHANGE THIS PART
void vexcodeInit(void) {
  // Nothing to initialize
}

//TROUBLESHOOTING----------------------------------------------------------------------------------------------------------------------------------------------
/*
Q: When I compile, an error occurs citing this file
A: Make sure your syntax is correct, the port number is correct, all arguments are filled in, the name matches in robotConfig.cpp and robotConfig.h. If there
   is still an issue, ask on Github issues page.

Q: What parts are required to be initialized
A: Generally, parts that are used in functions such as motors, inertial sensor, distance sensor, pistons, brain, and controller are initialized because they
   need to be initialized as an object before their functions can be used.

Q: A part I want to initialize is not in the structure explanation section
A: Go to https://api.vex.com/v5/home/cpp/index.html, smart port devices section, then click on whatever sensor you are trying to initialize.

Q: Radio initialization is not listed in the structure explanation and VEX API website
A: Radio initialization is automatically handled by the system, you do not have to manually initialize it yourself. Most advanced sensors have special ways of
   initialization, but most beginners do not use them. For more information on those sensors go to https://api.vex.com/v5/home/cpp/Smart_Port_Devices/index.html.

Q: My problem is not in the troubleshooting section
A: Go to the GitHub repository, click on the "Issues" tab, and submit a new issue describing your problem. I will respond.
*/